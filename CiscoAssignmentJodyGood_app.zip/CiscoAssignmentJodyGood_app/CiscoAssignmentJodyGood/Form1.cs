﻿//Jody Good Cisco Form App
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CiscoAssignmentJodyGood
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            // setting variables from text boxes
            int reg = int.Parse(txtReg.Text);
            int vegan = int.Parse(txtVegan.Text);
            int nut = int.Parse(txtNut.Text);
            int fish = int.Parse(txtFish.Text);
            int veg = int.Parse(txtVeg.Text);
            // resturant variables
            int regTotal = 0;
            int veganB = 0;
            int veganC = 0;
            int nutA = 0;
            int nutB = 0;
            int nutC = 0;
            int fishA = 0;
            int fishB = 0;
            int vegA = 0;
            int vegB = 0;
            int vegC = 0;

            
            //Regular Meals
            if (reg >= 30)
            {
                regTotal = reg - 30;
                reg = 30;

            }

            //Vegan Meals
            if (vegan >= 20)
            {
                veganB = vegan - 10;
                if (veganB > 10)
                {
                    veganC = vegan - 10;
                }
            }
            else if (vegan >= 10 && vegan < 20)
            {
                veganB = vegan - 10;

            } else if (vegan < 10) 
            {
                veganB = vegan;
            }

            // Nut Free Meals
            if (nut <= 15)
            {
                nutB = nut - 5;
                if (nutB <= 7)
                {
                    nutC = nutB - 7;
                }

            }
            else if (nut <= 8 && nut > 15)
            {
                nutA = 5;
                nutB = nut - 5;
                if (nutB <= 7)
                {
                    nutC = nutB - 7;

                }
                else
                {
                    nutA = 5;
                    nutB = nut - 5;
                }

                // Fish Free Meals
                if (fish <= 20)
                {
                    fishA = fish - 15;
                    fishB = 15;
                }
                else if (fish <= 10 && fish > 20)
                {
                    fishA = fish - 15;
                    fishB = 15;
                }
                else
                {
                    fishA = fish - 5;
                    if (fishA < 5)
                    { fishB = fish - 5; }
                }



                // Vegetarian Meals
                if (veg <= 20)
                {
                    vegA = veg - 18;
                    vegB = veg - 10;
                    if (vegB <= 8)
                    {
                        vegC = veganB - 8;
                    }

                }
                else if (veg <= 10 && veg > 20)
                {
                    vegA = veg - 18;
                    vegB = veg - 10;
                    if (vegB <= 8)
                    {
                        vegC = veganB - 8;
                    }
                }
                else
                {
                    vegA = 2;
                    vegB = veg - 2;


                }

               
            }
            txtResult.Text = "From Resturant A with a rating of 5 stars there will be: "
            +reg.ToString() + " regular meals, " + nutA.ToString() + " nut free meals " +
            fishA.ToString() + " fish free meals and " + vegA.ToString() + " vegetarian meals " +
            "\n" 
            + "From Resturant B with a rating of 4 stars there will be "
            + veganB.ToString() + " vegan meals " + nutB.ToString() + " nut free meals " +
            fishB.ToString() + " fish free meals and " + vegB.ToString() + " vegetarian meals "
            + "\n" 
            + "From Resturant C with a rating of 3 stars there will be "
            + veganC.ToString() + " vegan meals " + nutC.ToString() + " nut free meals " + vegC.ToString() + " vegetarian meals ";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFish.Text = "0";
            txtNut.Text = "0";
            txtReg.Text = "0";
            txtResult.Text = "0";
            txtVeg.Text = "0";
            txtVegan.Text = "0"; 
        }

        // validations
        private void txtReg_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txtVegan_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txtNut_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txtFish_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void txtVeg_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

