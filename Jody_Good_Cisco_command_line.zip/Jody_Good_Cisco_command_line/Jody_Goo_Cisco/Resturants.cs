﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jody_Goo_Cisco
{
    abstract class Resturants
    {
        private string id;

        // default constructor
        public Resturants(string i)
        {
            id = i;
        }

        // public method
        //public abstract double CalculateArea(); // abstract method


        public override string ToString()
        {
            return id;
        }


    }
}
