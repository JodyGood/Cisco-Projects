﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jody_Goo_Cisco
{
    class ResturantA : Resturants
    {
        private int rating = 0;
        private int reg = 30;
        private int nutFree = 5;
        private int vegan = 0;
        private int fishFree = 5;
        private int veg = 0;

        public ResturantA(string i, int ra, int r, int nf, int v, int ff, int vg): base(i)
        {
            rating = ra;
            reg = r;
            nutFree = nf;
            vegan = v;
            fishFree = ff;
            veg = vg;
        }

        public override string ToString()
        {
            return base.ToString() +
                " with a rating of " + rating + " stars, there will be " + reg + " regular meals ordered, "
                + nutFree + " nut free meals ordered "
                + vegan + " vegan meals ordred " + fishFree + " fish free meals ordered "
                + veg + " and vegetarian meals ordered.";
        }
    }
}
