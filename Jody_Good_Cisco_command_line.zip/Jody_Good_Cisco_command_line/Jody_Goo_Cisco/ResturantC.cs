﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jody_Goo_Cisco
{
    class ResturantC : Resturants
    {
        //Variables for requirments
        private int rating = 0;
        private int reg = 20;
        private int nutFree = 15;
        private int vegan = 5;
        private int fishFree = 15;
        private int veg = 5;

        public ResturantC(string i, int ra, int r, int nf, int v, int ff, int vg) : base(i)
        {
            rating = ra;
            reg = r;
            nutFree = nf;
            vegan = v;
            fishFree = ff;
            veg = vg;
        }

        // String
        public override string ToString()
        {
            return base.ToString() +
                " with a rating of " + rating + " stars, there will be " + reg + " regular meals ordered, " 
                + nutFree + " nut free meals ordered "
                + vegan + " vegan meals ordred " + fishFree + " fish free meals ordered "
                + veg + " and vegetarian meals ordered.";
        }
    }
}
