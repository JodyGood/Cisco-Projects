﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Jody Good CIsco Project Main Program


namespace Jody_Goo_Cisco
{
    abstract class Program
    {
        static void Main(string[] args)
        {
            // creating th objects from class
            //Shape shape = new Shape("Shape 1"); // cannot create object of abstract class
            ResturantA rA = new ResturantA("From Resturant A ", 5, 20, 5, 0, 5, 0); // object of class Circle
            ResturantB rB = new ResturantB("From Resturant B ", 4, 5, 0, 5, 0,5); // object of class Rectangle
            ResturantC rC = new ResturantC("From Resturant C ", 3, 0, 5, 0, 5, 0); // object of class Triangle

            List<Resturants> myResturants = new List<Resturants>(); // empty list
            myResturants.Add(rA);
            myResturants.Add(rB);
            myResturants.Add(rC);
            

            // display objects from the list
            foreach (Resturants s in myResturants)
                Console.WriteLine(s);

            

            Console.WriteLine("\n\nPress any key to finish");
            Console.ReadKey();
        }
    }
}
