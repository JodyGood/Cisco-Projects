﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jody_Goo_Cisco
{
    class ResturantB : Resturants
    {
        private int rating = 0;
        private int reg = 10;
        private int nutFree = 0;
        private int vegan =10;
        private int fishFree = 0;
        private int veg = 10;

        public ResturantB(string i, int ra, int r, int nf, int v, int ff, int vg) : base(i)
        {
            
            rating = ra;
            reg = r;
            nutFree = nf;
            vegan = v;
            fishFree = ff;
            veg = vg;
        }

        public override string ToString()
        {
            return base.ToString() +
                " with a rating of " + rating + " stars, there will be " + reg + " regular meals ordered, "
                + nutFree + " nut free meals ordered "
                + vegan + " vegan meals ordred " + fishFree + " fish free meals ordered "
                + veg + " and vegetarian meals ordered.";
        }
    }
}
